SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=false

REPLACE="
"
sleep 2
ui_print ""
ui_print "wait.."
ui_print "succes ~ @reljawa"